export declare const canPreviewFile: (type: string) => boolean;
export declare const downloadBlob: (arrayBuf: any, name: string, mimeType: string) => void;
export declare const downloadFile: (attachment: any, getPConnect: any, setImages: any, bForceDownload: boolean) => void;
type addAttachmentProps = {
    currentCategory: string;
    attachment: any;
    listOfAttachments: any;
    getPConnect: any;
    setImages: any;
    useLightBox: boolean;
    setElemRef: any;
};
export declare const addAttachment: (props: addAttachmentProps) => void;
export {};
//# sourceMappingURL=utils.d.ts.map