/// <reference types="react" />
export type UtilityListProps = {
    heading: string;
    useAttachmentEndpoint: boolean;
    categories?: string;
    dataPage: string;
    icon?: 'information' | 'polaris' | 'clipboard';
    displayFormat?: 'list' | 'tiles';
    useLightBox?: boolean;
    enableDownloadAll?: boolean;
    getPConnect?: any;
};
export declare const PegaExtensionsDisplayAttachments: (props: UtilityListProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: UtilityListProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map