/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
interface EeExtVerifiedTextInputProps extends PConnFieldProps {
    displayAsStatus?: boolean;
    isTableFormatter?: boolean;
    hasSuggestions?: boolean;
    variant?: any;
    formatter: string;
    isVerified: string;
    updateDataPage: string;
    refreshDataPage: string;
    enableUpdate: boolean;
}
export declare const formatExists: (formatterVal: string) => boolean;
export declare const textFormatter: (formatter: string, value: string) => any;
declare const _default: (props: EeExtVerifiedTextInputProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map