export declare const configProps: {
    value: string;
    label: string;
    placeholder: string;
    helperText: string;
    testId: string;
    hasSuggestions: boolean;
    displayMode: string;
    hideLabel: boolean;
    readOnly: boolean;
    required: boolean;
    disabled: boolean;
    status: string;
    validatemessage: string;
    isVerified: boolean;
    enableUpdate: boolean;
};
export declare const stateProps: {
    value: string;
    hasSuggestions: boolean;
};
export declare const fieldMetadata: {
    classID: string;
    type: string;
    maxLength: number;
    displayAs: string;
    label: string;
    isVerified: boolean;
};
//# sourceMappingURL=mock.d.ts.map