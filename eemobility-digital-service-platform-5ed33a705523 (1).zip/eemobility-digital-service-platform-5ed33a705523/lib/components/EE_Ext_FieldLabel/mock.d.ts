export declare const configProps: {
    value: string;
    label: string;
    required: boolean;
    variant: string;
};
//# sourceMappingURL=mock.d.ts.map