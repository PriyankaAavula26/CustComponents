/// <reference types="react" />
declare const _default: (props: Omit<any, "ref">) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map