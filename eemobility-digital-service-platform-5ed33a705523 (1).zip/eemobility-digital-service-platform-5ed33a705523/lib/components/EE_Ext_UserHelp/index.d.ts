export default function EeExtUserHelp(props: any): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map