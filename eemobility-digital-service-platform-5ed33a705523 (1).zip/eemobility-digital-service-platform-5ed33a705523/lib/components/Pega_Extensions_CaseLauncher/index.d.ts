/// <reference types="react" />
export type CaseLauncherProps = {
    /** Card heading */
    heading: string;
    /** Description of the case launched by the widget */
    description: string;
    /** Class name of the case; used as property when launching pyStartCase  */
    classFilter: any;
    /** Primary button label  */
    labelPrimaryButton: string;
    getPConnect: any;
};
export declare const PegaExtensionsCaseLauncher: (props: CaseLauncherProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: CaseLauncherProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map