/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
interface EeExtActionableLinkProps extends PConnFieldProps {
    label: string;
    variant: 'link' | 'text' | 'primary' | 'secondary' | 'simple' | undefined;
    url: string;
    dataPage: string;
    setField: string;
    setFieldValue: string;
    openAs: string;
    getPConnect: any;
}
declare const _default: (props: EeExtActionableLinkProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map