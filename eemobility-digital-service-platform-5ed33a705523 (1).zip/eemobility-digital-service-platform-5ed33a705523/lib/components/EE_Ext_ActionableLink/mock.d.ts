export declare const configProps: {
    label: string;
    url: string;
    variant: string;
    dataPage: string;
    openAs: string;
};
export declare const stateProps: {
    value: string;
    hasSuggestions: boolean;
};
//# sourceMappingURL=mock.d.ts.map