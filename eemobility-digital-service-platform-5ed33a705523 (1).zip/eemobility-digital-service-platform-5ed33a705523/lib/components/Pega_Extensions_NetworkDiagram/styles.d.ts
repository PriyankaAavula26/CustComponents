import { type themeDefinition } from '@pega/cosmos-react-core';
declare const _default: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {
    height: string;
    theme: typeof themeDefinition;
}, never>;
export default _default;
//# sourceMappingURL=styles.d.ts.map