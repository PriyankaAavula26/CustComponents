/// <reference types="react" />
export interface NetworkDiagramProps {
    /** Heading of the widget */
    heading: string;
    /** Name of the data page that will be called to get the Nodes and Edges */
    dataPage: string;
    /** Height of the diagram
     * @default 40rem
     */
    height?: string;
    /** Show the minimap on the diagram
     * @default true
     */
    showMinimap?: boolean;
    /** Show the controls panel in the diagram
     * @default true
     */
    showControls?: boolean;
    /** Show the refresh button to reload the DP and recenter the diagram
     * @default true
     */
    showRefresh?: boolean;
    /** Type of layout for the edges
     * @default bezier
     */
    edgePath?: 'bezier' | 'straight' | 'step';
    getPConnect: any;
}
export declare const PegaExtensionsNetworkDiagram: (props: NetworkDiagramProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: NetworkDiagramProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map