import { type NodeProps } from 'reactflow';
declare const CustomNode: (props: NodeProps) => import("react/jsx-runtime").JSX.Element;
export default CustomNode;
//# sourceMappingURL=CustomNode.d.ts.map