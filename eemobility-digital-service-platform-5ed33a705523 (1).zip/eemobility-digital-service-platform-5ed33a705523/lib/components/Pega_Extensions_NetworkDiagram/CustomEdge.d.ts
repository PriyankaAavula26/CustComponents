import { type EdgeProps } from 'reactflow';
declare const CustomEdge: (props: EdgeProps) => import("react/jsx-runtime").JSX.Element;
export default CustomEdge;
//# sourceMappingURL=CustomEdge.d.ts.map