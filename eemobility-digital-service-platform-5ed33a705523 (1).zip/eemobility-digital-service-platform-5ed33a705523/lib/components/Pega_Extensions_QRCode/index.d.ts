/// <reference types="react" />
type QRCodeCompProps = {
    label: string;
    value: string;
    inputProperty: string;
    helperText?: string;
    validatemessage?: string;
    hideLabel: boolean;
    readOnly?: boolean;
    testId?: string;
    getPConnect: any;
};
export declare const PegaExtensionsQRCode: (props: QRCodeCompProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: QRCodeCompProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map