export default function Logo({ fillColor }: {
    fillColor: string;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Logo.d.ts.map