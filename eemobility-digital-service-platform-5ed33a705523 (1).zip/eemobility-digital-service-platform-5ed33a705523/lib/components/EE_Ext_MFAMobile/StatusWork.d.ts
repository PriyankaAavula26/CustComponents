export default function StatusWorkRenderer({ value }: any): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=StatusWork.d.ts.map