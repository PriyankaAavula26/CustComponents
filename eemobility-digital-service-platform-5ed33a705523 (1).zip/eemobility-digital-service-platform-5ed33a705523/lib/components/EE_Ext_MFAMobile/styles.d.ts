declare const _default: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {}, never>;
export default _default;
export declare const VerifiedTag: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {}, never>;
export declare const StyledTickImage: import("styled-components").StyledComponent<"svg", import("styled-components").DefaultTheme, {}, never>;
//# sourceMappingURL=styles.d.ts.map