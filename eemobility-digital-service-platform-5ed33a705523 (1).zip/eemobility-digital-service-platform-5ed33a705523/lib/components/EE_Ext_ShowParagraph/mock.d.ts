declare const configProps: {
    dataPage: string;
    className: string;
    paragraphName: string;
};
export default configProps;
//# sourceMappingURL=mock.d.ts.map