/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
interface EeExtShowParagraphProps extends PConnFieldProps {
    dataPage: string;
    className: string;
    paragraphName: string;
}
declare const _default: (props: EeExtShowParagraphProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map