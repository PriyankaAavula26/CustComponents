import { themeDefinition } from '@pega/cosmos-react-core';
declare const StyledCard: import("styled-components").StyledComponent<"article", import("styled-components").DefaultTheme, {
    theme: typeof themeDefinition;
}, never>;
export default StyledCard;
//# sourceMappingURL=styles.d.ts.map