export default function EeExtEditOperator(props: any): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map