/// <reference types="react" />
export type CheckboxTriggerProps = {
    getPConnect?: any;
    label: string;
    dataPage: string;
    value?: boolean;
    helperText?: string;
    placeholder?: string;
    validatemessage?: string;
    hideLabel?: boolean;
    disabled?: boolean;
    readOnly?: boolean;
    required?: boolean;
    testId?: string;
    fieldMetadata?: any;
    additionalProps?: any;
    displayMode?: string;
};
export declare const PegaExtensionsCheckboxTrigger: (props: CheckboxTriggerProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: CheckboxTriggerProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map