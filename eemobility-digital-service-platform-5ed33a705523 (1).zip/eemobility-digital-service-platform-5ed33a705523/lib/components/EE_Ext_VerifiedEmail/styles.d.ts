declare const _default: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {}, never>;
export default _default;
export declare const EmailVerifed: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {}, never>;
export declare const StyledTickImage: import("styled-components").StyledComponent<"img", import("styled-components").DefaultTheme, {}, never>;
//# sourceMappingURL=styles.d.ts.map