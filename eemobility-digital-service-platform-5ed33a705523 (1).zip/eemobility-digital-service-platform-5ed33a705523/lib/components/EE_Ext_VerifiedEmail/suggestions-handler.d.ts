export declare const suggestionsHandler: (accepted: boolean, pConn: any, setStatus: any) => void;
//# sourceMappingURL=suggestions-handler.d.ts.map