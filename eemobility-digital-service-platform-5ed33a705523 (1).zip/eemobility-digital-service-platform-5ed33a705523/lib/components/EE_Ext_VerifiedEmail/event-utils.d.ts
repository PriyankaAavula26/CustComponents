declare const handleEvent: (actions: any, eventType: string, propName: string, value: string) => void;
export default handleEvent;
//# sourceMappingURL=event-utils.d.ts.map