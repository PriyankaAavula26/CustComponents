/// <reference types="react" />
export type MaskedInputProps = {
    getPConnect?: any;
    label: string;
    mask: string;
    value?: string;
    helperText?: string;
    placeholder?: string;
    validatemessage?: string;
    hideLabel?: boolean;
    disabled?: boolean;
    readOnly?: boolean;
    required?: boolean;
    testId?: string;
    fieldMetadata?: any;
    additionalProps?: any;
    displayMode?: string;
    variant?: any;
    hasSuggestions?: boolean;
};
export declare const PegaExtensionsMaskedInput: (props: MaskedInputProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: MaskedInputProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map