/// <reference types="react" />
type BannerProps = {
    /** Display type of rendering
     * @default success
     */
    variant: 'success' | 'info' | 'warning' | 'urgent';
    /** Name of the data page to get the messages */
    dataPage?: string;
    getPConnect: any;
};
export declare const PegaExtensionsBanner: (props: BannerProps) => import("react/jsx-runtime").JSX.Element | null;
declare const _default: (props: BannerProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map