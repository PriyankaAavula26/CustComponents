export default function EeExtAnnouncements(props: any): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map