/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
interface EeExtOpenUrlAsEmbedProps extends PConnFieldProps {
    label: string;
}
declare const _default: (props: EeExtOpenUrlAsEmbedProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map