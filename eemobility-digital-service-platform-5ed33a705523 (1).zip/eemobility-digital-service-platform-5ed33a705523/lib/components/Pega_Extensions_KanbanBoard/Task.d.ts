export type TaskProps = {
    title: string;
    index: number;
    insKey: string;
    classname: string;
    groupValue: string;
    id: string;
    details?: any;
    getDetails: any;
    editTask: any;
};
export declare const Task: (props: TaskProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Task.d.ts.map