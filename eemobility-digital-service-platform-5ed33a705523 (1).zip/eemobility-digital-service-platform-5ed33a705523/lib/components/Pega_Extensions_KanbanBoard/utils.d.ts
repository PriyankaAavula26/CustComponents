type loadDetailsProps = {
    id: string;
    classname: string;
    detailsDataPage: string;
    detailsViewName: string;
    getPConnect: any;
};
export declare const loadDetails: (props: loadDetailsProps) => Promise<undefined>;
type updateGroupValueProps = {
    groupValue: string;
    groupProperty: string;
    columns: any;
    setColumns: any;
    task: any;
    getPConnect: any;
};
export declare const updateGroupValue: (props: updateGroupValueProps) => void;
export {};
//# sourceMappingURL=utils.d.ts.map