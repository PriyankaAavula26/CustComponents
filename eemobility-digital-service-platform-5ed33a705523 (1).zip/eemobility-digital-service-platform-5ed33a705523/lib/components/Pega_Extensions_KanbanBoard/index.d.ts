/// <reference types="react" />
type KanbanBoardProps = {
    heading: string;
    dataPage: string;
    createClassname?: string;
    height?: string;
    groups: string;
    groupProperty: string;
    detailsDataPage: string;
    detailsViewName: string;
    getPConnect: any;
};
export declare const PegaExtensionsKanbanBoard: (props: KanbanBoardProps) => import("react/jsx-runtime").JSX.Element | null;
declare const _default: (props: KanbanBoardProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map