export type ColumnProps = {
    title: string;
    id: string;
    tasks: any;
};
export declare const Column: (props: ColumnProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Column.d.ts.map