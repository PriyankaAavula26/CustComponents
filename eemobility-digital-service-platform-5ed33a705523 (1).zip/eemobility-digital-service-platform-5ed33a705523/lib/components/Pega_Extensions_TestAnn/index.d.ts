/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
interface PegaExtensionsTestAnnProps extends PConnFieldProps {
    datasource: Array<any>;
    header: string;
    description: string;
    whatsnewlink: string;
    image: string;
}
declare const _default: (props: PegaExtensionsTestAnnProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map