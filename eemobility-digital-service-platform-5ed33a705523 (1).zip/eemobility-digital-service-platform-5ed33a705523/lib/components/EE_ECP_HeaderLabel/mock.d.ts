export declare const configProps: {
    label: string;
    labelColor: string;
    labelSize: string;
    labelWeight: string;
};
export declare const stateProps: {
    value: string;
    hasSuggestions: boolean;
};
//# sourceMappingURL=mock.d.ts.map