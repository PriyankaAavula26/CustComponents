/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
interface EEHeaderLabelProps extends PConnFieldProps {
    label: string;
    labelColor: string;
    labelSize: string;
    labelWeight: string;
}
declare const _default: (props: EEHeaderLabelProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map