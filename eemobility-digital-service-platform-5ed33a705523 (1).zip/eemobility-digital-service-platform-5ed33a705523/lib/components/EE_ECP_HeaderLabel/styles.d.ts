declare const _default: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {}, never>;
export default _default;
//# sourceMappingURL=styles.d.ts.map