/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
interface EeExtMessageBannerProps extends PConnFieldProps {
    variant: 'success' | 'info' | 'warning' | 'urgent';
    dataPage?: string;
    getPConnect: any;
}
export declare const EeExtMessageBanner: (props: EeExtMessageBannerProps) => import("react/jsx-runtime").JSX.Element | null;
declare const _default: (props: EeExtMessageBannerProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map