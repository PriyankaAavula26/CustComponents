export declare const SimpleContent: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {}, never>;
export declare const GroupedContent: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {}, never>;
//# sourceMappingURL=styles.d.ts.map