/// <reference types="react" />
type EeExtEcpShortcutProps = {
    /** Display type of rendering
     * @default simple
     */
    displayType: 'simple' | 'grouped';
    /** Heading for the card - only used if displayType is simple
     * @default Shortcuts
     */
    heading?: string;
    /** Label of each page (comma-separated) - only used if displayType is simple */
    names?: string;
    /** Name of each page with the class (e.g. Data-Portal.SearchPage), comma-separated list - only used if displayType is simple */
    pages?: string;
    /** JSON object passed a string - only used if displayType is grouped */
    pageJSON?: string;
    getPConnect: any;
};
export declare const EeExtEcpShortcut: (props: EeExtEcpShortcutProps) => import("react/jsx-runtime").JSX.Element | null;
declare const _default: (props: EeExtEcpShortcutProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map