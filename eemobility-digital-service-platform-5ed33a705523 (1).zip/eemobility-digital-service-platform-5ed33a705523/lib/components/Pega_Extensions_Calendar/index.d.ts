/// <reference types="react" />
type CalendarProps = {
    heading: string;
    dataPage: string;
    createClassname?: string;
    defaultViewMode: 'Monthly' | 'Weekly' | 'Daily';
    nowIndicator: boolean;
    weekendIndicator: boolean;
    getPConnect: any;
};
export declare const PegaExtensionsCalendar: (props: CalendarProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: CalendarProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map