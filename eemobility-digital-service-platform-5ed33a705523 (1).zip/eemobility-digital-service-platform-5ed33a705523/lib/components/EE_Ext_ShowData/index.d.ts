/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
interface EeExtShowDataProps extends PConnFieldProps {
    dataPage: string;
    pyGUID: string;
    viewName: string;
    getPConnect: any;
}
declare const _default: (props: EeExtShowDataProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map