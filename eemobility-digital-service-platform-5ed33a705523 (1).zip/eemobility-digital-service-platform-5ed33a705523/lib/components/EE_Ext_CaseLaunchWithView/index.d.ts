/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
interface EeExtCaseLaunchWithViewProps extends PConnFieldProps {
    heading: string;
    description: string;
    classFilter: any;
    labelPrimaryButton: string;
    openCaseView: boolean;
    getPConnect: any;
}
export declare const EeExtCaseLaunchWithView: (props: EeExtCaseLaunchWithViewProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: EeExtCaseLaunchWithViewProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map