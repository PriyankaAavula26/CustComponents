import { themeDefinition } from '@pega/cosmos-react-core';
declare const StyledEeExtCaseLaunchWithViewWrapper: import("styled-components").StyledComponent<"article", import("styled-components").DefaultTheme, {
    theme: typeof themeDefinition;
}, never>;
export default StyledEeExtCaseLaunchWithViewWrapper;
//# sourceMappingURL=styles.d.ts.map