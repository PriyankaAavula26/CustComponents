/**
 * Given the PConnect object of a Template component, retrieve the children
 * metadata of all regions.
 * @param {Function} pConnect PConnect of a Template component.
 */
export default function getAllFields(regionID: number, pConnect: any): any;
//# sourceMappingURL=utils.d.ts.map