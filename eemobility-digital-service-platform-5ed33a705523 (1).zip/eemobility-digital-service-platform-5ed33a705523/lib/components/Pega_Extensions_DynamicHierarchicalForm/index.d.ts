/// <reference types="react" />
export interface DynamicHierarchicalFormProps {
    /** Heading for this view */
    label?: string;
    /** Show the heading of the view
     *  @default true
     */
    showLabel?: boolean;
    /** Label of the refresh action button
     * @default Refresh details
     */
    refreshActionLabel?: string;
    /** Show the refresh action button
     * @default true
     */
    showRefreshAction: boolean;
    /** Show the multi-select combo-box
     * @default true
     */
    enableItemSelection: boolean;
    getPConnect?: any;
}
export declare const PegaExtensionsDynamicHierarchicalForm: (props: DynamicHierarchicalFormProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: DynamicHierarchicalFormProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map