declare const configProps: {
    caseId: string;
    viewName: string;
};
export default configProps;
//# sourceMappingURL=mock.d.ts.map