/// <reference types="react" />
export type CaseLauncherProps = {
    /** Card heading */
    caseId: string;
    /** Description of the case launched by the widget */
    viewName: string;
    getPConnect: any;
};
export declare const EELoadCaseView: (props: CaseLauncherProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: CaseLauncherProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map