/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
interface EeExtensionsFirstTemplateProps extends PConnFieldProps {
    showLabel: boolean;
    children: any;
}
declare const _default: (props: EeExtensionsFirstTemplateProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map