/// <reference types="react" />
export declare enum BarcodeType {
    CODE128 = "CODE128",
    EAN8 = "EAN8",
    EAN13 = "EAN13",
    UPC = "upc",
    CODE39 = "CODE39",
    ITF14 = "ITF14",
    MSI = "MSI",
    PHARMACODE = "pharmacode"
}
type BarCodeExtProps = {
    format: BarcodeType;
    label: string;
    value: string;
    inputProperty: string;
    displayValue: boolean;
    helperText?: string;
    validatemessage?: string;
    hideLabel: boolean;
    readOnly?: boolean;
    testId?: string;
    getPConnect: any;
};
export declare const PegaExtensionsBarCode: (props: BarCodeExtProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: BarCodeExtProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map