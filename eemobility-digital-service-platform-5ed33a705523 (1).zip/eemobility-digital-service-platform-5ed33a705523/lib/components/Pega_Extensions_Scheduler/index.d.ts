/// <reference types="react" />
type PegaExtensionsSchedulerProps = {
    getPConnect: any;
    value: string;
    hideLabel: boolean;
    testId?: string;
    label?: string;
    eventDate?: string;
    startTime?: string;
    endTime?: string;
};
/**
 * convert a timestamp like '20200210T170100' or '20200210' into a valid Date object
 */
export declare const convertDate: (v: string) => Date | undefined;
export declare const convertTime: (v: string) => string | undefined;
export declare const PegaExtensionsScheduler: (props: PegaExtensionsSchedulerProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: PegaExtensionsSchedulerProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map