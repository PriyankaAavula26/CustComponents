/// <reference types="react" />
type FieldGroupAsRowProps = {
    heading: string;
    children: any;
};
export declare const PegaExtensionsFieldGroupAsRow: (props: FieldGroupAsRowProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: FieldGroupAsRowProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map