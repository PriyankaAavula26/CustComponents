/// <reference types="react" />
type PasswordInputProps = {
    getPConnect: any;
    label: string;
    value: string;
    helperText?: string;
    placeholder?: string;
    validatemessage?: string;
    hideLabel: boolean;
    disabled?: boolean;
    readOnly?: boolean;
    required?: boolean;
    testId?: string;
    fieldMetadata?: any;
    additionalProps?: any;
    displayMode?: string;
    variant?: any;
    hasSuggestions?: boolean;
};
export declare const PegaExtensionsPasswordInput: (props: PasswordInputProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: PasswordInputProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map