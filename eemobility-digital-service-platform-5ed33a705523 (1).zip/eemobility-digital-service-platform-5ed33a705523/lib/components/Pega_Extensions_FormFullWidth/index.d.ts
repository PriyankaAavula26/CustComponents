/// <reference types="react" />
type FormFullWidthProps = {
    heading: string;
    NumCols: string;
    children: any;
};
export declare const PegaExtensionsFormFullWidth: (props: FormFullWidthProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: FormFullWidthProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map