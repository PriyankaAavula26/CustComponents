export declare const StyledCardContent: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {
    maxHeight: string;
}, never>;
export declare const StyledGenAIComponent: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {}, never>;
//# sourceMappingURL=styles.d.ts.map