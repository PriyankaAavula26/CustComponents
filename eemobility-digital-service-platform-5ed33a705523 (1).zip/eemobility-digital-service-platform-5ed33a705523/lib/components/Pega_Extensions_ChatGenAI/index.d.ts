/// <reference types="react" />
type ChatGenAIProps = {
    heading: string;
    dataPage: string;
    maxHeight: string;
    sendAllUserContext: boolean;
    getPConnect: any;
};
export declare const PegaExtensionsChatGenAI: (props: ChatGenAIProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: ChatGenAIProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map