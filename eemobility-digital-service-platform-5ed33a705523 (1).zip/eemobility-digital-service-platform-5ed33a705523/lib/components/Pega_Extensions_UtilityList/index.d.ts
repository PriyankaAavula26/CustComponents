/// <reference types="react" />
type UtilityListProps = {
    heading?: string;
    icon: 'information' | 'polaris' | 'clipboard';
    dataPage: string;
    setCaseID: boolean;
    primaryField: string;
    secondaryFields?: string;
    secondaryFieldTypes?: string;
    getPConnect: any;
};
export declare const PegaExtensionsUtilityList: (props: UtilityListProps) => import("react/jsx-runtime").JSX.Element | null;
declare const _default: (props: UtilityListProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map