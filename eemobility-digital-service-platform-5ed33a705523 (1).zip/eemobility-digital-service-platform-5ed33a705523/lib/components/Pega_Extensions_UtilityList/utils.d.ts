export type ObjectProps = {
    propName: string;
    type: string;
    getPConnect: any;
    item: any;
};
export declare const renderObjectField: ({ propName, type, item, getPConnect }: ObjectProps) => any;
//# sourceMappingURL=utils.d.ts.map