/// <reference types="react" />
type SignatureCaptureProps = {
    getPConnect: any;
    label: string;
    value: string;
    helperText?: string;
    validatemessage?: string;
    hideLabel: boolean;
    disabled?: boolean;
    readOnly?: boolean;
    required?: boolean;
    testId?: string;
    displayMode?: string;
    variant?: any;
};
export declare const PegaExtensionsSignatureCapture: (props: SignatureCaptureProps) => import("react/jsx-runtime").JSX.Element | null;
declare const _default: (props: SignatureCaptureProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map