import React from 'react';
import SignaturePad, { type Options } from 'signature_pad';
interface SignatureProps extends Options {
    canvasProps?: React.CanvasHTMLAttributes<HTMLCanvasElement>;
    signaturePadRef?: React.MutableRefObject<SignaturePad | undefined>;
    onEndStroke?: CallableFunction;
}
declare const Signature: (props: SignatureProps) => import("react/jsx-runtime").JSX.Element;
export default Signature;
//# sourceMappingURL=Signature.d.ts.map