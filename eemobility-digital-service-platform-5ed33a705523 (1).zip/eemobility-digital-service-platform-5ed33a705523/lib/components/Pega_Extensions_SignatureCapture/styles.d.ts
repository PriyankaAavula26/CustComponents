/// <reference types="react" />
export declare const StyledSignatureContent: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {}, never>;
export declare const StyledButtonsWrapper: import("styled-components").StyledComponent<import("react").FunctionComponent<import("@pega/cosmos-react-core").FlexProps & import("@pega/cosmos-react-core").ForwardProps>, import("styled-components").DefaultTheme, {}, never>;
export declare const StyledSignatureReadOnlyContent: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {}, never>;
//# sourceMappingURL=styles.d.ts.map