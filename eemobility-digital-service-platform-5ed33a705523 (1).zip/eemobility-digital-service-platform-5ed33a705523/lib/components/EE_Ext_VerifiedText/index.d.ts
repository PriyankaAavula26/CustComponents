/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
interface EeExtVerifiedTextProps extends PConnFieldProps {
}
declare const _default: (props: EeExtVerifiedTextProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map