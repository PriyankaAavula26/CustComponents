declare const configProps: {
    dataPage: string;
    cardMinWidth: string;
};
export default configProps;
//# sourceMappingURL=mock.d.ts.map