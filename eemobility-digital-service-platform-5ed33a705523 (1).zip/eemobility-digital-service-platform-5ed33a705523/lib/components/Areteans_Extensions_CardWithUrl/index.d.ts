/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
export {};
interface AreteansExtensionsCardWithUrlProps extends PConnFieldProps {
    cardMinWidth?: string;
    dataPage: string;
    getPConnect: any;
}
declare const _default: (props: AreteansExtensionsCardWithUrlProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map