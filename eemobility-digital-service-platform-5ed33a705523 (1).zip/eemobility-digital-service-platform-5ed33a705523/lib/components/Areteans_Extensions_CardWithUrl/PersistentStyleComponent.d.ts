declare const PersistentStyleComponent: () => null;
export default PersistentStyleComponent;
//# sourceMappingURL=PersistentStyleComponent.d.ts.map