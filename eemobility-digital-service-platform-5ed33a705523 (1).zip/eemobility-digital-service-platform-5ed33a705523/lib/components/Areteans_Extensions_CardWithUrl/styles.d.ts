export declare const StyledCardContent: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {}, never>;
export declare const MainCard: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {
    rendering: string;
    minWidth: string;
}, never>;
export declare const StyledButton: import("styled-components").StyledComponent<"button", import("styled-components").DefaultTheme, {}, never>;
//# sourceMappingURL=styles.d.ts.map