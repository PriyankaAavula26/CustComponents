/// <reference types="react" />
export type TableLayoutProps = {
    heading: string;
    displayFormat: 'spreadsheet' | 'financialreport' | 'radio-button-card';
    selectionProperty?: string;
    currencyFormat: 'standard' | 'compact' | 'parentheses';
    getPConnect?: any;
};
export declare const PegaExtensionsCompareTableLayout: (props: TableLayoutProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: TableLayoutProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map