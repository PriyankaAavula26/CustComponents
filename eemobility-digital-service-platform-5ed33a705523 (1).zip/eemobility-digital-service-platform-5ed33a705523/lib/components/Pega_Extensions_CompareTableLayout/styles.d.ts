declare const _default: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {
    displayFormat: string;
}, never>;
export default _default;
//# sourceMappingURL=styles.d.ts.map