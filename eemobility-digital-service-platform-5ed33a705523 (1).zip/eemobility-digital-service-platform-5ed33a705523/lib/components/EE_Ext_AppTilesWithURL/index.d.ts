/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
interface EeExtAppTilesWithUrlProps extends PConnFieldProps {
    cardMinWidth?: string;
    dataPage: string;
    getPConnect: any;
}
declare const _default: (props: EeExtAppTilesWithUrlProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map