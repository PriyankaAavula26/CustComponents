declare function Loader(): import("react/jsx-runtime").JSX.Element;
export default Loader;
//# sourceMappingURL=Loader.d.ts.map