declare const StyledLoaderOverlay: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {}, never>;
declare const StyledLoader: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {}, never>;
export { StyledLoaderOverlay, StyledLoader };
//# sourceMappingURL=Loader.styled.d.ts.map