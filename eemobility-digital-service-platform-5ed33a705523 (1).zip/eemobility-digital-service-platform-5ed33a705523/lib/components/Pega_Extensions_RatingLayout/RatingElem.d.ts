type RatingElemProps = {
    value: number;
    label: string;
    propIndex: number;
    path: string;
    getPConnect?: any;
};
declare const RatingElem: (props: RatingElemProps) => import("react/jsx-runtime").JSX.Element;
export default RatingElem;
//# sourceMappingURL=RatingElem.d.ts.map