/// <reference types="react" />
type RatingLayoutProps = {
    label?: string;
    showLabel?: boolean;
    getPConnect?: any;
    minWidth?: string;
    numCategories?: number;
    numRatings?: number;
};
export declare const PegaExtensionsRatingLayout: (props: RatingLayoutProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: RatingLayoutProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map