/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
interface EeExtWelcomeUsrProps extends PConnFieldProps {
    label: string;
    labelColor: string;
    labelSize: string;
    labelWeight: string;
}
declare const _default: (props: EeExtWelcomeUsrProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map