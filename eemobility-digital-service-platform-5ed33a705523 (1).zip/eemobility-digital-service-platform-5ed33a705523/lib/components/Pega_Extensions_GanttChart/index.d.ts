/// <reference types="react" />
import { type GanttChartProps } from './utils';
export declare const PegaExtensionsGanttChart: (props: GanttChartProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: GanttChartProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map