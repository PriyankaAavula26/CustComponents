import { type themeDefinition, Card } from '@pega/cosmos-react-core';
export declare const StyledHoverTooltipCard: typeof Card;
declare const _default: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {
    theme: typeof themeDefinition;
}, never>;
export default _default;
//# sourceMappingURL=styles.d.ts.map