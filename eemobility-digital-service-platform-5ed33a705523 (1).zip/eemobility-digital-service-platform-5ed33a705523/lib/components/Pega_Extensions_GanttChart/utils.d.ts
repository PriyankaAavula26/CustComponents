import type { Task as GTRTask, StylingOption, ViewMode as GTRViewModeType } from 'gantt-task-react';
import type { DefaultTheme } from 'styled-components';
export type ViewModeType = 'Hourly' | 'Daily' | 'Weekly' | 'Monthly' | 'Yearly';
export interface Task extends GTRTask {
    extendedProps: any;
}
export type CategoryType = 'PROJECT' | 'TASK' | 'MILESTONE';
export type GanttChartProps = {
    heading?: string;
    createClassname?: string;
    dataPage: string;
    categoryFieldName: string;
    parentFieldName: string;
    dependenciesFieldName: string;
    startDateFieldName: string;
    endDateFieldName: string;
    progressFieldName: string;
    showDetailsColumns: boolean;
    defaultViewMode: ViewModeType;
    detailsDataPage: string;
    detailsViewName: string;
    getPConnect: any;
};
/** Loads data for Gantt chart from a datapage */
export declare const loadGanttData: (dataPage: string, categoryFieldName: string, parentFieldName: string, dependenciesFieldName: string, startDateFieldName: string, endDateFieldName: string, progressFieldName: string) => Promise<Task[]>;
/** Prepare custom style options for Gantt from theme and hides popover */
export declare const getCustomStyleOptions: (theme: DefaultTheme, TooltipContent?: any) => StylingOption;
/** Maps ViewMode to Gantt ViewMode */
export declare const ViewModeMap: Record<ViewModeType, GTRViewModeType>;
/** Adjust column width based on viewMode */
export declare const getColumnWidth: (viewMode: ViewModeType) => number;
export declare const viewModeOptions: {
    id: string;
    name: string;
}[];
type loadDetailsProps = {
    id: string;
    classname: string;
    detailsDataPage: string;
    detailsViewName: string;
    getPConnect: any;
};
export declare const loadDetails: (props: loadDetailsProps) => Promise<undefined>;
export type UpdateItemDetails = {
    item: Task;
    updatedFieldValueList: any;
    getPConnect: any;
};
export declare const updateItemDetails: (props: UpdateItemDetails) => Promise<any>;
export {};
//# sourceMappingURL=utils.d.ts.map