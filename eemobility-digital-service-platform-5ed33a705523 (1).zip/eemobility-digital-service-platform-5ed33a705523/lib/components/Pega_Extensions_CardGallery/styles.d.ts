import { type themeDefinition } from '@pega/cosmos-react-core';
export declare const StyledCardContent: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {
    theme: typeof themeDefinition;
}, never>;
export declare const MainCard: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {
    rendering: string;
    minWidth: string;
}, never>;
//# sourceMappingURL=styles.d.ts.map