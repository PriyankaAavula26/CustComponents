type loadDetailsProps = {
    id: string;
    classname: string;
    detailsDataPage: string;
    detailsViewName: string;
    getPConnect: any;
};
export declare const loadDetails: (props: loadDetailsProps) => Promise<undefined>;
export declare const getFilters: (filters: any) => {
    logic: string;
    filterConditions: any;
} | null;
export {};
//# sourceMappingURL=utils.d.ts.map