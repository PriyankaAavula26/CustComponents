/// <reference types="react" />
type CardGalleryProps = {
    heading: string;
    dataPage: string;
    useInDashboard: boolean;
    numCards?: number;
    createClassname?: string;
    rendering: 'vertical' | 'horizontal';
    minWidth?: string;
    detailsDataPage: string;
    detailsViewName: string;
    getPConnect: any;
};
export declare const PegaExtensionsCardGallery: (props: CardGalleryProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: CardGalleryProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map