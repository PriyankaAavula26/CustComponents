export type TaskProps = {
    title: string;
    insKey: string;
    status: string;
    details?: any;
    editTask: any;
};
export declare const Task: (props: TaskProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Task.d.ts.map