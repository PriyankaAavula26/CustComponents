/// <reference types="react" />
type ActionableButtonProps = {
    label: string;
    value: string;
    localAction: string;
    getPConnect: any;
};
export declare const PegaExtensionsActionableButton: (props: ActionableButtonProps) => import("react/jsx-runtime").JSX.Element | null;
declare const _default: (props: ActionableButtonProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map