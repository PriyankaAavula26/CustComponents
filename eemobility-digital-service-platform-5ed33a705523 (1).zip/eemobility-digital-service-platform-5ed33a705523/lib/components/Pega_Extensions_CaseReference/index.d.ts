/// <reference types="react" />
type ActionableButtonProps = {
    value: string;
    fieldMetadata: any;
    selectionProperty: string;
    getPConnect: any;
};
export declare const PegaExtensionsCaseReference: (props: ActionableButtonProps) => import("react/jsx-runtime").JSX.Element | null;
declare const _default: (props: ActionableButtonProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map