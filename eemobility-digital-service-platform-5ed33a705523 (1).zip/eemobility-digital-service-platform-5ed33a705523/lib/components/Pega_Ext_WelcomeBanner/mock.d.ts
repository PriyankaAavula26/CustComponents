export declare const configProps: {
    label: string;
    labelColor: string;
    labelSize: string;
    labelWeight: string;
};
//# sourceMappingURL=mock.d.ts.map