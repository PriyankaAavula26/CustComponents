/// <reference types="react" />
import type { PConnFieldProps } from './PConnProps';
interface PegaExtWelcomeBannerProps extends PConnFieldProps {
    label: string;
    labelColor: string;
    labelSize: string;
    labelWeight: string;
    getPConnect: any;
}
declare const _default: (props: PegaExtWelcomeBannerProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map