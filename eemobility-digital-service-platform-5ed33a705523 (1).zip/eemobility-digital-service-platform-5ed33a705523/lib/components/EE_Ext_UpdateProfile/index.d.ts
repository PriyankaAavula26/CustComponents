export default function EeExtUpdateProfile(props: any): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map