/// <reference types="react" />
type PegaExtensionsImageMagnifyProps = {
    value: string;
    /**
     * Width selection - if set to widthpx, you need to configure customWidth
     * @default defaultWidth
     */
    widthSel?: 'defaultWidth' | 'widthpx';
    /**
     * customWidth (in px) - only used if  widthSel = widthpx
     * @default 100
     */
    customWidth?: number;
    /**
     * Configuration for the image alt text
     * @default constant
     */
    altText?: 'constant' | 'propertyRef';
    /**
     * Configure of the alt text if constant
     */
    altTextOfImage?: string;
    /**
     * Configure of the alt text if property ref
     */
    propaltTextOfImage?: string;
    /**
     * Magnifier trigger (hover, click or doubleclick)
     * @default magTriggerHover
     */
    magnifyTrigger?: 'magTriggerHover' | 'magTriggerClick' | 'magTriggerDoubleClick';
    /**
     * Magnifier mode
     * @default magSideBySide
     */
    magnifyMode?: 'magSideBySide' | 'magAdvanced';
    /**
     * Always magnify in place
     * @default false
     */
    alwaysInPlace?: boolean;
    /**
     * Show on left
     * @default false
     */
    switchSides?: boolean;
    /**
     * Fill available Space
     * @default false
     */
    fillAvailableSpace?: boolean;
    /**
     * Align to top
     * @default false
     */
    fillAlignTop?: boolean;
    /**
     * Gap left
     * @default 0
     */
    fillGapLeft?: number;
    /**
     * Gap Right
     * @default 0
     */
    fillGapRight?: number;
    /**
     * Gap Top
     * @default 0
     */
    fillGapTop?: number;
    /**
     * Gap Bottom
     * @default 0
     */
    fillGapBottom?: number;
    /**
     * Zoom top position (px)
     * @default 0
     */
    zoomTop?: number;
    /**
     * Zoom left position (px)
     * @default 0
     */
    zoomLeft?: number;
    /**
     * Zoom display height (%)
     * @default 100
     */
    zoomHeight?: number;
    /**
     * Zoom display width (px)
     * @default 300
     */
    zoomWidth?: number;
    /**
     * Preview image right offset (px)
     * @default 0
     */
    previewRightOffset?: number;
    /**
     * Zoom display z-index value
     * @default 999
     */
    zoomZIndex?: number;
};
export declare const PegaExtensionsImageMagnify: (props: PegaExtensionsImageMagnifyProps) => import("react/jsx-runtime").JSX.Element | null;
declare const _default: (props: PegaExtensionsImageMagnifyProps) => JSX.Element;
export default _default;
//# sourceMappingURL=index.d.ts.map