import { withConfiguration, Banner } from '@pega/cosmos-react-core';
import type { PConnFieldProps } from './PConnProps';
import StyledEeExtMessageBannerWrapper from './styles';
import { useState, useCallback, useEffect } from 'react';

interface EeExtMessageBannerProps extends PConnFieldProps {
  variant: 'success' | 'info' | 'warning' | 'urgent';
  dataPage?: string;
  getPConnect: any;
}

export const EeExtMessageBanner = (props: EeExtMessageBannerProps) => {
  const { variant = 'success', dataPage = '', getPConnect } = props;
  const [messages, setMessages] = useState([]);
  const [show, setShow] = useState(true);

  const loadMessages = useCallback(() => {
    if (dataPage) {
      const pConn = getPConnect();
      const CaseInstanceKey = pConn.getValue(
        (window as any).PCore.getConstants().CASE_INFO.CASE_INFO_ID
      );
      const payload = {
        dataViewParameters: [{ pyID: CaseInstanceKey }]
      };
      (window as any).PCore.getDataApiUtils()
        .getData(dataPage, payload, pConn.getContextName())
        .then((response: any) => {
          if (response.data.data !== null) {
            setMessages(
              response.data.data.map((message: any) => {
                return {
                  description: message.pyDescription,
                  action: {
                    href: message.URLLink,
                    onClick: (e: React.ChangeEvent<HTMLInputElement>) => {
                      e.preventDefault();
                      window.open(message.URLLink, '_blank');
                    },
                    text: message.URLLabel
                  }
                };
              })
            );
          }
        })
        .catch(() => {});
    }
  }, [dataPage, getPConnect]);

  useEffect(() => {
    const caseID = getPConnect().getValue(
      (window as any).PCore.getConstants().CASE_INFO.CASE_INFO_ID
    );
    const filter = {
      matcher: 'TASKLIST',
      criteria: {
        ID: caseID
      }
    };
    const attachSubId = (window as any).PCore.getMessagingServiceManager().subscribe(
      filter,
      () => {
        loadMessages();
      },
      getPConnect().getContextName()
    );
    return () => {
      (window as any).PCore.getMessagingServiceManager().unsubscribe(attachSubId);
    };
  }, [getPConnect, loadMessages]);

  useEffect(() => {
    loadMessages();
  }, [dataPage, getPConnect, loadMessages]);

  if (messages?.length === 0) return null;
  return (
    <StyledEeExtMessageBannerWrapper>
      {show ? (
        <Banner variant={variant} messages={messages} onDismiss={() => setShow(false)} />
      ) : (
        ''
      )}
    </StyledEeExtMessageBannerWrapper>
  );
};

export default withConfiguration(EeExtMessageBanner);
