import styled, { css } from 'styled-components';
import { Button, Icon, Tooltip, useElement, registerIcon } from '@pega/cosmos-react-core';
import * as userSolidIcon from '@pega/cosmos-react-core/lib/components/Icon/icons/user-plus-solid.icon';

registerIcon(userSolidIcon);

const WrapperDiv = styled.div(() => {
  return css`
    .main-container {
      color: rgb(255, 255, 255);
      background-color: rgba(255, 255, 255, 0);
      padding: calc(0.78125rem) 0;
      position: relative;
      display: flex;
      align-items: center;
      font-weight: 400;
      text-decoration: none;
      width: 100%;
    }

    .main-container:hover {
      background-color: rgb(5, 124, 105);
    }

    .sub-container {
      flex-shrink: 0;
      margin: 0px calc(1.4375rem);
    }
  `;
});

export default function EeExtUpdateProfile(props: any) {
  const { getPConnect, className, label } = props;

  const itemClick = () => {
    const options = {
      flowType: 'pyStartCase',
      containerName: 'primary',
      openCaseViewAfterCreate: false
    };
    getPConnect().getActionsApi().createWork(className, options);
  };
  const [el, setEl] = useElement();

  return (
    <WrapperDiv>
      <Button
        variant='text'
        icon
        compact={false}
        onClick={itemClick}
        className='main-container'
        ref={setEl}
      >
        <span className='sub-container'>
          {el && (
            <Tooltip target={el} placement='right' showDelay='none' hideDelay='none'>
              {label}
            </Tooltip>
          )}

          <Icon name='user-plus-solid' />
        </span>
        <span>{label}</span>
      </Button>
    </WrapperDiv>
  );
}
