
/* eslint-disable react/jsx-no-useless-fragment */
// @ts-nocheck
import type { Meta, StoryObj } from '@storybook/react';

import EeExtUpdateProfile from './index';


import configProps from './mock';

const meta: Meta<typeof EeExtUpdateProfile> = {
  title: 'EeExtUpdateProfile',
  component: EeExtUpdateProfile,
  excludeStories: /.*Data$/
};

export default meta;
type Story = StoryObj<typeof EeExtUpdateProfile>;

export const BaseEeExtUpdateProfile: Story = args => {

  const props = {
    label: configProps.label,
    header: configProps.header,
    description: configProps.description,
    image: configProps.image,
    datasource: configProps.datasource,
    whatsnewlink: configProps.whatsnewlink
};

return (
    <>
      <EeExtUpdateProfile {...props} {...args} />
    </>
  );
};

BaseEeExtUpdateProfile.args = {
  header: configProps.header,
  description: configProps.description
};
