import styled, { keyframes } from 'styled-components';

const spinAnimation = keyframes`
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
`;

const StyledLoaderOverlay = styled.div`
  position: relative;
  width: 100%;
  height: 100%;
  min-height: 10rem;
  z-index: 111;
  background-color: transparent;
`;

const StyledLoader = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 112;
  width: 40px;
  height: 40px;
  border: 4px solid #f3f3f3;
  border-top: 4px solid #06957d;
  border-radius: 50%;
  -webkit-animation: ${spinAnimation} 1s linear infinite;
  animation: ${spinAnimation} 1s linear infinite;
`;

export { StyledLoaderOverlay, StyledLoader };
