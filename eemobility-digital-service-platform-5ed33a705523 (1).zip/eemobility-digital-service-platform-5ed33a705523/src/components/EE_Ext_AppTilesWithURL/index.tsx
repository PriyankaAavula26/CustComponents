import { useEffect, useState, useCallback, useRef } from 'react';
import { withConfiguration, Card } from '@pega/cosmos-react-core';
import type { PConnFieldProps } from './PConnProps';
import { MainCard, StyledButton } from './styles';
import Loader from './Loader';

interface EeExtAppTilesWithUrlProps extends PConnFieldProps {
  cardMinWidth?: string;
  dataPage: string;
  getPConnect: any;
}
interface AppItem {
  appName: string;
  header: string;
  icon: string;
  desc: string;
  url: string;
  isActive: string;
  id: string;
  disabled: boolean;
}

interface AppElementProps {
  item: AppItem;
}
const AppElement: React.FC<AppElementProps> = ({ item }) => {
  useEffect(() => {
    const btnElem = document.querySelectorAll('.disabled-card');
    btnElem.forEach(btn => {
      const parentToBtn = btn.parentElement;
      if (parentToBtn) {
        parentToBtn.classList.add('has-disabled-btn');
      }
    });
  }, [item.disabled]);
  return (
    <StyledButton
      className={item.disabled ? 'disabled-card AD1-card-container' : 'AD1-card-container'}
      title={item.disabled ? 'Pending Approval' : item.appName}
      onClick={e => {
        e.preventDefault();
        if (item.disabled) {
          e.preventDefault();
          return;
        }
        window.open(item.url, '_blank');
      }}
    >
      <div className={item.disabled ? 'application-name-disabled' : 'application-name'}>
        {item.appName}
      </div>
      <div className='content-area'>
        <div className='application-icon'>
          <img src={`data:image/svg+xml;base64,${item.icon}`} alt={item.appName} />
        </div>
        <h2>{item.header}</h2>
        <p>{item.desc}</p>
      </div>
    </StyledButton>
  );
};

function EeExtAppTilesWithUrl(props: EeExtAppTilesWithUrlProps) {
  const { getPConnect, dataPage, cardMinWidth = '400px' } = props;
  const [appList, setAppList] = useState<AppItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const PConnect = getPConnect();
  const dataViewName = dataPage;
  const context = PConnect.getContextName();

  const isMounted = useRef(true);

  const initialLoad = useCallback(() => {
    if (dataViewName) {
      setIsLoading(true);
      PCore.getDataApiUtils()
        .getData(dataViewName, {}, context)
        .then((response: any) => {
          if (response.data.data !== null) {
            if (isMounted.current) {
              setAppList(
                response.data.data.map((entry: any, index: number) => {
                  return {
                    header: entry.Header,
                    appName: entry.Name,
                    desc: entry.Description,
                    icon: entry.IconSource,
                    url: entry.URL,
                    id: index,
                    disabled: entry.IsDisabled
                  };
                })
              );
            }
            setIsLoading(false);
          } else {
            setAppList([]);
          }
        })
        .catch((error: any) => {
          setAppList([]);
          console.log(error);
        });
    }
    return () => {
      isMounted.current = false;
    };
  }, [context, dataViewName]);

  useEffect(() => {
    const filter = {
      matcher: 'DATAPAGE_UPDATED',
      criteria: {
        datapage: dataViewName
      }
    };
    const attachSubId = (window as any).PCore.getMessagingServiceManager().subscribe(
      filter,
      () => {
        initialLoad();
      },
      getPConnect().getContextName()
    );
    return () => {
      (window as any).PCore.getMessagingServiceManager().unsubscribe(attachSubId);
    };
  }, [getPConnect, initialLoad, dataViewName]);

  useEffect(() => {
    initialLoad();
    return () => {
      isMounted.current = false;
    };
  }, [initialLoad, context, dataViewName]);

  return (
    <MainCard minWidth={cardMinWidth} rendering='horizontal'>
      {isLoading ? (
        <Loader />
      ) : (
        Array.from(appList).map(item => {
          return (
            <Card key={item.id}>
              <AppElement item={item} />
            </Card>
          );
        })
      )}
    </MainCard>
  );
}

export default withConfiguration(EeExtAppTilesWithUrl);
