import { StyledLoaderOverlay, StyledLoader } from './styles/Loader.styled';

function Loader() {
  return (
    <StyledLoaderOverlay>
      <StyledLoader></StyledLoader>
    </StyledLoaderOverlay>
  );
}

export default Loader;
