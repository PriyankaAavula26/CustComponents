/* eslint-disable react/jsx-no-useless-fragment */
// @ts-nocheck
import type { Meta, StoryObj } from '@storybook/react';

import EeExtEcpShortcut from './index';

import configProps from './mock';

const meta: Meta<typeof EeExtEcpShortcut> = {
  title: 'EeExtEcpShortcut',
  component: EeExtEcpShortcut,
  excludeStories: /.*Data$/
};

export default meta;
type Story = StoryObj<typeof EeExtEcpShortcut>;

const setPCore = () => {
  (window as any).PCore = {
    getConstants: () => {
      return {
        CASE_INFO: {}
      };
    },
    getSemanticUrlUtils: () => {
      return {
        getResolvedSemanticURL: () => {
          return '/case/case-1';
        },
        getActions: () => {
          return { ACTION_SHOWVIEW: 'ACTION_SHOWVIEW' };
        }
      };
    }
  };
};

export const BaseEeExtEcpShortcut: Story = args => {
  setPCore();
  const props = {
    ...args,
    getPConnect: () => {
      return {
        getContextName: () => '',
        getValue: () => 'C-123',
        getActionsApi: () => {
          return {
            showPage: (name: string, classname: string) => {
              // eslint-disable-next-line no-alert
              alert(`show page ${classname}.${name}`);
            }
          };
        }
      };
    }
  };

  return (
    <>
      <EeExtEcpShortcut {...props} {...args} />
    </>
  );
};

BaseEeExtEcpShortcut.args = {
  displayType: 'simple',
  heading: 'Shortcuts',
  names: 'Welcome,Information,Help,My Search',
  pages: 'Data-Portal.Page1,Data-Portal.Page2,Work-.Page3,https://www.pega.com',
  pageJSON:
    '{"categories": [{ "heading": "Category1", "links" : [{ "name": "Page1" , "page": "Data-Portal.Page1"}, { "name": "Page2" , "page": "Data-Portal.Page2"},{ "name": "Page3" , "page": "Data-Portal.Page3"}]},{ "heading": "Category2", "links" : [{ "name": "Page4" , "page": "Data-Portal.Page4"}, { "name": "Page5" , "page": "Data-Portal.Page5"},{ "name": "Page6" , "page": "Data-Portal.Page6"}]},{ "heading": "Category3", "links" : [{ "name": "Welcome" , "page": "Data-Portal.Page1"}, { "name": "Information" , "page": "Data-Portal.Page2"},{ "name": "Help" , "page": "Data-Portal.Page3"}]}]}'
};
