
/* eslint-disable react/jsx-no-useless-fragment */
// @ts-nocheck
import type { Meta, StoryObj } from '@storybook/react';

import EeExtCaseLaunchWithView from './index';


import configProps from './mock';

const meta: Meta<typeof EeExtCaseLaunchWithView> = {
  title: 'EeExtCaseLaunchWithView',
  component: EeExtCaseLaunchWithView,
  excludeStories: /.*Data$/
};

export default meta;
type Story = StoryObj<typeof EeExtCaseLaunchWithView>;

export const BaseEeExtCaseLaunchWithView: Story = args => {

  const props = {
    label: configProps.label,
    header: configProps.header,
    description: configProps.description,
    image: configProps.image,
    datasource: configProps.datasource,
    whatsnewlink: configProps.whatsnewlink
};

return (
    <>
      <EeExtCaseLaunchWithView {...props} {...args} />
    </>
  );
};

BaseEeExtCaseLaunchWithView.args = {
  header: configProps.header,
  description: configProps.description
};
