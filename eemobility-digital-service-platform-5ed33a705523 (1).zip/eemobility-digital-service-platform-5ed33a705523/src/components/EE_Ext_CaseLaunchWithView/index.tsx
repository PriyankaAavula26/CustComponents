import {
  withConfiguration,
  Card,
  CardHeader,
  CardContent,
  CardFooter,
  Text,
  Button
} from '@pega/cosmos-react-core';
import type { PConnFieldProps } from './PConnProps';

import StyledEeExtCaseLaunchWithViewWrapper from './styles';

interface EeExtCaseLaunchWithViewProps extends PConnFieldProps {
  heading: string;
  description: string;
  classFilter: any;
  labelPrimaryButton: string;
  openCaseView: boolean;
  getPConnect: any;
}

export const EeExtCaseLaunchWithView = (props: EeExtCaseLaunchWithViewProps) => {
  const { heading, description, classFilter, labelPrimaryButton, openCaseView, getPConnect } =
    props;
  const pConn = getPConnect();
  const createCase = (className: string) => {
    const options = {
      flowType: 'pyStartCase',
      containerName: 'primary',
      openCaseViewAfterCreate: false
    };
    options.openCaseViewAfterCreate = openCaseView;

    pConn.getActionsApi().createWork(className, options);
  };

  return (
    <Card as={StyledEeExtCaseLaunchWithViewWrapper}>
      <CardHeader>
        <Text variant='h2'>{heading}</Text>
      </CardHeader>
      <CardContent>{description}</CardContent>
      <CardFooter justify='end'>
        <Button
          variant='primary'
          onClick={() => {
            createCase(classFilter);
          }}
        >
          {labelPrimaryButton}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default withConfiguration(EeExtCaseLaunchWithView);
