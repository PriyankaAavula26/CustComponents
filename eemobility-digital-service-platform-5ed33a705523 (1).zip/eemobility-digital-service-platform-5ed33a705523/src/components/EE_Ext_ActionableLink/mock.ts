// @ts-nocheck
export const configProps = {
  label: 'Text Sample',
  url: 'https://google.com',
  variant: 'link',
  dataPage: 'D_DPage',
  openAs: 'window'
};

export const stateProps = {
  value: '.TextSample',
  hasSuggestions: false
};
