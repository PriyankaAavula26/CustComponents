/* eslint-disable react/jsx-no-useless-fragment */
// @ts-nocheck
import { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';

import { stateProps, configProps } from './mock';

import EeExtActionableLink from './index';

const meta: Meta<typeof EeExtActionableLink> = {
  title: 'EeExtActionableLink',
  component: EeExtActionableLink,
  excludeStories: /.*Data$/
};

export default meta;
type Story = StoryObj<typeof EeExtActionableLink>;

if (!window.PCore) {
  window.PCore = {};
}

const viewData = {
  pyValue: 'https://pega.com'
};

window.PCore.getDataPageUtils = () => {
  return {
    getPageDataAsync: () => {
      return new Promise(resolve => {
        resolve(viewData);
      });
    }
  };
};

export const BaseEeExtActionableLink: Story = args => {
  const [value, setValue] = useState(configProps.value);

  const props = {
    ...configProps,
    getPConnect: () => {
      return {
        getStateProps: () => {
          return {
            value: 'C-123'
          };
        },
        getActionsApi: () => {
          return {
            openLocalAction: {
              bind: () => {
                return (name: string, options: any) => {
                  // eslint-disable-next-line no-alert
                  alert(`Launch local action ${name} for ${options.caseID}`);
                };
              }
            }
          };
        }
      };
    }
  };

  return (
    <>
      <EeExtActionableLink {...props} {...args} />
    </>
  );
};

BaseEeExtActionableLink.args = {
  label: configProps.label,
  variant: configProps.variant,
  url: configProps.url,
  dataPage: configProps.dataPage,
  openAs: configProps.openAs
};
