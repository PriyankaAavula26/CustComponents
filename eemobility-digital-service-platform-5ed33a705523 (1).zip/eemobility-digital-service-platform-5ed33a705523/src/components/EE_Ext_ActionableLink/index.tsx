import { Flex, Link, withConfiguration } from '@pega/cosmos-react-core';

import type { PConnFieldProps } from './PConnProps';

import { useState, useEffect } from 'react';

import StyledEeExtActionableLinkWrapper from './styles';

// interface for props
interface EeExtActionableLinkProps extends PConnFieldProps {
  // If any, enter additional props that only exist on TextInput here
  label: string;
  variant: 'link' | 'text' | 'primary' | 'secondary' | 'simple' | undefined;
  url: string;
  dataPage: string;
  setField: string;
  setFieldValue: string;
  openAs: string;
  getPConnect: any;
}

// Duplicated runtime code from Constellation Design System Component

// props passed in combination of props from property panel (config.json) and run time props from Constellation
// any default values in config.pros should be set in defaultProps at bottom of this file
function EeExtActionableLink(props: EeExtActionableLinkProps) {
  const { label, variant, url, dataPage, setField, setFieldValue, openAs, getPConnect } = props;

  const [linkUrl, setLinkUrl] = useState<string>('');
  let finalUrl = '';
  let hUrl = '';

  const dataViewName = dataPage;
  const pConn = getPConnect();
  const metadata = pConn.getRawMetadata();

  useEffect(() => {
    if (dataViewName != '') {
      const options = {
        invalidateCache: true
      };
      const context = 'app/primary_1';
      PCore.getDataPageUtils()
        .getPageDataAsync(dataViewName, context, {}, options)
        .then((response: any) => {
          console.log(response);
          setLinkUrl(response.pyValue);
        })
        .catch(() => {});
    }
  }, [dataViewName]);

  if (dataViewName == '' && url != '') {
    setLinkUrl(url);
  }

  if (openAs == 'tab') {
    finalUrl = linkUrl;
    hUrl = linkUrl;
  } else if (openAs == 'window') {
    finalUrl = linkUrl;
    hUrl = '';
  }

  function OnClickURL() {
    console.log(finalUrl);
    if (openAs == 'window') {
      window.open(
        finalUrl,
        '_blank',
        'toolbar=yes,scrollbars=yes,resizable=no,top=550,left=75,width=1200,height=700'
      );
    }
    if (setField && metadata.config.fieldName) {
      const prop = metadata.config.fieldName.replace('@P ', '');
      pConn.setValue(prop, setFieldValue);
    }
    return null;
  }

  return (
    <StyledEeExtActionableLinkWrapper>
      <Flex container={{ direction: 'row' }}>
        <Link href={hUrl} variant={variant} onClick={OnClickURL}>
          {label}
        </Link>
      </Flex>
    </StyledEeExtActionableLinkWrapper>
  );
}

export default withConfiguration(EeExtActionableLink);
