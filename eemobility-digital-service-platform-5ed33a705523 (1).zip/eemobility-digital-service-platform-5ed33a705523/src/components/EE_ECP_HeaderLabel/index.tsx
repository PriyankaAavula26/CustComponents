import { withConfiguration } from '@pega/cosmos-react-core';
import { Text } from '@pega/cosmos-react-core';

import type { PConnFieldProps } from './PConnProps';
import StyledCard from './styles';

interface EEHeaderLabelProps extends PConnFieldProps {
  label: string;
  labelColor: string;
  labelSize: string;
  labelWeight: string;
}

function EEHeaderLabel(props: EEHeaderLabelProps) {
  const { label, labelColor, labelSize, labelWeight } = props;

  // The styling passed from configuration is used here to style the label
  const labelStyle = { color: labelColor, 'font-size': labelSize, 'font-weight': labelWeight };

  return (
    // The label provided from App Studio is displayed before first name.
    <Text as={StyledCard}>
      <span style={labelStyle}>{label}</span>
    </Text>
  );
}

export default withConfiguration(EEHeaderLabel);
