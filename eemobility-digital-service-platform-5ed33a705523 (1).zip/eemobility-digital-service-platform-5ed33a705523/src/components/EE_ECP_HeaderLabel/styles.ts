// individual style, comment out above, and uncomment here and add styles
import styled, { css } from 'styled-components';

export default styled.div(() => {
  return css`
    margin-top: 1rem;
    margin-bottom: 1rem;
  `;
});
