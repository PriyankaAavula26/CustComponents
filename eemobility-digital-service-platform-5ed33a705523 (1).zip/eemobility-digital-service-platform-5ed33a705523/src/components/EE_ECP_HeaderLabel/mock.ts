// @ts-nocheck
export const configProps = {
  label: 'Text Sample',
  labelColor: 'green',
  labelSize: '16px',
  labelWeight: 'bold'
};

export const stateProps = {
  value: '.TextSample',
  hasSuggestions: false
};
