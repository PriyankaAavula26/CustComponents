export default function Logo({ fillColor }: { fillColor: string }) {
  return (
    <svg
      className='bi bi-google'
      height='1.125rem'
      width='1.125rem'
      viewBox='0 0 25 25'
      xmlns='http://www.w3.org/2000/svg'
      fill={fillColor}
    >
      <path d='m3.464 11.371 6.222 5.974L21.582 5 23 6.371 9.732 20 2 12.743l1.464-1.372Z' />
    </svg>
  );
}
