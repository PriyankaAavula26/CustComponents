// individual style, comment out above, and uncomment here and add styles
import styled, { css } from 'styled-components';

export default styled.div(() => {
  return css`
    margin: 0px 0;
    & .form-items {
      display: flex;
      align-items: center;
      justify-content: space-around;
    }
    & .item-right {
      text-align: right;
      float: right;
      width: 100%;
      padding: 0;
    }

    & .item-left {
      text-align: left;
      float: left;
      width: 100%;
      padding: 0;
    }
  `;
});

export const VerifiedTag = styled.div`
  display: flex;
  align-items: center;
  max-width: max-content;
  margin-top: calc(0.15625rem);
  //font-size: max(0.75rem, 12px);
  font-size: 14px;
  word-break: break-word;
  color: rgb(21, 111, 53);
  border: 0px;
  clip: rect(0px, 0px, 0px, 0px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0px;
  position: absolute;
  white-space: nowrap;
  width: 1px;
  user-select: none;
  display: contents;
`;

export const StyledTickImage = styled.svg`
  display: inline-block;
  text-align: left;
  fill: currentcolor;
  height: 1.125rem;
  width: 1.125rem;
  vertical-align: middle;
  flex-shrink: 0;
  margin-inline-end: 0.5ch;
`;
