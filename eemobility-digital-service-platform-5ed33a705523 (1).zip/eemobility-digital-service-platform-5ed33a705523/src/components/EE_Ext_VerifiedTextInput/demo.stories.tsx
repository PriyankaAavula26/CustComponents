/* eslint-disable react/jsx-no-useless-fragment */
// @ts-nocheck
import type { Meta, StoryObj } from '@storybook/react';

import EeExtVerifiedTextInput from './index';

import { stateProps, fieldMetadata, configProps } from './mock';

const meta: Meta<typeof EeExtVerifiedTextInput> = {
  title: 'EeExtVerifiedTextInput',
  component: EeExtVerifiedTextInput,
  excludeStories: /.*Data$/
};

export default meta;
type Story = StoryObj<typeof EeExtVerifiedTextInput>;

if (!window.PCore) {
  window.PCore = {};
}

const viewData = {
  pyValue: 'https://google.com',
  mobilePhone: '+619830580801'
};

window.PCore.getDataPageUtils = () => {
  return {
    getPageDataAsync: () => {
      return new Promise(resolve => {
        resolve(viewData);
      });
    }
  };
};

export const BaseEeExtVerifiedTextInput: Story = args => {
  const props = {
    value: configProps.value,
    placeholder: configProps.placeholder,
    label: configProps.label,
    helperText: configProps.helperText,
    testId: configProps.testId,
    hasSuggestions: configProps.hasSuggestions,
    fieldMetadata,
    validatemessage: '',
    getPConnect: () => {
      return {
        getStateProps: () => {
          return stateProps;
        },
        getActionsApi: () => {
          return {
            updateFieldValue: () => {
              /* nothing */
            },
            triggerFieldChange: () => {
              /* nothing */
            }
          };
        },
        ignoreSuggestion: () => {
          /* nothing */
        },
        acceptSuggestion: () => {
          /* nothing */
        },
        setInheritedProps: () => {
          /* nothing */
        },
        resolveConfigProps: () => {
          /* nothing */
        }
      };
    }
  };

  return (
    <>
      <EeExtVerifiedTextInput {...props} {...args} />
    </>
  );
};

BaseEeExtVerifiedTextInput.args = {
  label: configProps.label,
  helperText: configProps.helperText,
  placeholder: configProps.placeholder,
  readOnly: configProps.readOnly,
  disabled: configProps.disabled,
  status: configProps.status,
  isVerified: configProps.isVerified,
  enableUpdate: configProps.enableUpdate
};
