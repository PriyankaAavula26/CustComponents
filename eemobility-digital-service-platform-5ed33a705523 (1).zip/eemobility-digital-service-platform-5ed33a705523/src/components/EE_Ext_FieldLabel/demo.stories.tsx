/* eslint-disable react/jsx-no-useless-fragment */
// @ts-nocheck
import { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';

import { stateProps, configProps } from './mock';

import EeExtFieldLabel from './index';

const meta: Meta<typeof EeExtFieldLabel> = {
  title: 'EeExtFieldLabel',
  component: EeExtFieldLabel,
  excludeStories: /.*Data$/
};

export default meta;
type Story = StoryObj<typeof EeExtFieldLabel>;

export const BaseEeExtFieldLabel: Story = args => {
  const [value, setValue] = useState(configProps.value);

  const props = {
    value,
    placeholder: configProps.placeholder,
    label: configProps.label,
    testId: configProps.testId,
    hasSuggestions: configProps.hasSuggestions,

    getPConnect: () => {
      return {
        getStateProps: () => {
          return stateProps;
        },
        getActionsApi: () => {
          return {
            updateFieldValue: (propName, theValue) => {
              setValue(theValue);
            },
            triggerFieldChange: () => {
              /* nothing */
            }
          };
        },
        ignoreSuggestion: () => {
          /* nothing */
        },
        acceptSuggestion: () => {
          /* nothing */
        },
        setInheritedProps: () => {
          /* nothing */
        },
        resolveConfigProps: () => {
          /* nothing */
        }
      };
    }
  };

  return (
    <>
      <EeExtFieldLabel {...props} {...args} />
    </>
  );
};

BaseEeExtFieldLabel.args = {
  value: configProps.value,
  label: configProps.label,
  required: configProps.required,
  variant: configProps.variant
};
