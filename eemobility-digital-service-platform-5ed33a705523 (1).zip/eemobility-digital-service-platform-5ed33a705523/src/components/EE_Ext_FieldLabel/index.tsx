import { Text, withConfiguration } from '@pega/cosmos-react-core';

import StyledEeExtFieldLabelWrapper from './styles';

// Duplicated runtime code from Constellation Design System Component

// props passed in combination of props from property panel (config.json) and run time props from Constellation
// any default values in config.pros should be set in defaultProps at bottom of this file
function EeExtFieldLabel(props: any) {
  const { label, isRequired, variant } = props;

  return (
    <StyledEeExtFieldLabelWrapper>
      <Text className={isRequired ? 'FieldLabel Required' : 'FieldLabel'} variant={variant}>
        {label}
      </Text>
    </StyledEeExtFieldLabelWrapper>
  );
}

export default withConfiguration(EeExtFieldLabel);
