// individual style, comment out above, and uncomment here and add styles
import styled, { css } from 'styled-components';

export default styled.div(() => {
  return css`
    margin: 0px 0;

    .Required::after {
      display: inline;
      content: '*';
      vertical-align: top;
      color: rgb(217, 28, 41);
    }
  `;
});
