// @ts-nocheck
export const configProps = {
  value: 'TestValue',
  label: 'TestLabel',
  required: true,
  variant: 'secondary'
};
