
/* eslint-disable react/jsx-no-useless-fragment */
// @ts-nocheck
import type { Meta, StoryObj } from '@storybook/react';

import EeExtAnnouncements from './index';


import configProps from './mock';

const meta: Meta<typeof EeExtAnnouncements> = {
  title: 'EeExtAnnouncements',
  component: EeExtAnnouncements,
  excludeStories: /.*Data$/
};

export default meta;
type Story = StoryObj<typeof EeExtAnnouncements>;

export const BaseEeExtAnnouncements: Story = args => {

  const props = {
    label: configProps.label,
    header: configProps.header,
    description: configProps.description,
    image: configProps.image,
    datasource: configProps.datasource,
    whatsnewlink: configProps.whatsnewlink
};

return (
    <>
      <EeExtAnnouncements {...props} {...args} />
    </>
  );
};

BaseEeExtAnnouncements.args = {
  header: configProps.header,
  description: configProps.description
};
