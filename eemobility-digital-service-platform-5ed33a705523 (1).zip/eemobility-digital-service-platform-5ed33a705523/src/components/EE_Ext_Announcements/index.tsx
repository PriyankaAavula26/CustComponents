import styled, { css } from 'styled-components';

import { useEffect, useState } from 'react';

import { Button, Icon, Tooltip, useElement, registerIcon } from '@pega/cosmos-react-core';
import * as megaPhoneSolidIcon from '@pega/cosmos-react-core/lib/components/Icon/icons/megaphone-solid.icon';

registerIcon(megaPhoneSolidIcon);

const WrapperDiv = styled.div(() => {
  return css`
    .main-container {
      color: rgb(255, 255, 255);
      background-color: rgba(255, 255, 255, 0);
      padding: calc(0.78125rem) 0;
      position: relative;
      display: flex;
      align-items: center;
      font-weight: 400;
      text-decoration: none;
      width: 100%;
    }

    .main-container:hover {
      background-color: rgb(5, 124, 105);
    }

    .count-container {
      position: absolute;
      inset-inline-start: calc(2rem);
      top: calc(0.25rem);
      padding: 0 calc(0.25rem);
      display: inline-block;
      block-size: 1rem;
      border-radius: calc(4999.5rem);
      color: #ffffff;
      background-color: rgb(217, 28, 41);
      box-shadow: rgb(255 255 255 / 10%) 0px 0px 0px 0.0625rem inset;
      font-size: calc(0.75rem);
      font-weight: 700;
      line-height: normal;
      text-align: center;
      padding-inline: 0.5rem;
      margin: 0px;
    }

    .sub-container {
      flex-shrink: 0;
      margin: 0px calc(1.4375rem);
    }
  `;
});

export default function EeExtAnnouncements(props: any) {
  const { getPConnect, label, dataPage, landingPage, landingPageClass } = props;

  const [count, setCount] = useState(0);

  const itemClick = () => {
    getPConnect()
      .getActionsApi()
      .showPage(landingPage, landingPageClass)
      .then(() => {
        setCount(0);
      })

      .catch((error: any) => {
        console.log(`error${error}`);
      });
  };

  const [el, setEl] = useElement();

  useEffect(() => {
    PCore.getDataPageUtils()
      .getPageDataAsync(dataPage, '')
      .then((response: any) => {
        const countNum = response.pxResultCount;
        setCount(countNum);
      })

      .catch((error: any) => {
        console.log(`error${error}`);
      });
  }, [dataPage]);

  return (
    <WrapperDiv>
      <Button
        variant='link'
        icon
        compact={false}
        onClick={itemClick}
        className='main-container'
        ref={setEl}
      >
        <span className='sub-container'>
          {el && (
            <Tooltip target={el} placement='right' showDelay='none' hideDelay='none'>
              {label}
            </Tooltip>
          )}

          <Icon name='megaphone-solid' />

          {count > 0 && <span className='count-container'>{count}</span>}
        </span>

        <span>{label}</span>
      </Button>
    </WrapperDiv>
  );
}
