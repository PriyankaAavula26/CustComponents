/* eslint-disable react/jsx-no-useless-fragment */
// @ts-nocheck
import type { Meta, StoryObj } from '@storybook/react';

import EeExtShowParagraph from './index';

import configProps from './mock';

const meta: Meta<typeof EeExtShowParagraph> = {
  title: 'EeExtShowParagraph',
  component: EeExtShowParagraph,
  excludeStories: /.*Data$/
};

export default meta;
type Story = StoryObj<typeof EeExtShowParagraph>;

if (!window.PCore) {
  window.PCore = {};
}

const viewData = {
  pySourceStream: `<h1 id="p-ea074837-c513-4e90-a9cd-7c94e0848583"><span style="color:#c0392b;">Terms of Use</span></h1> <p>These Terms of Use are applicable to your access to and use of the websites, applications, and other online services operated by Pegasystems Inc. (&ldquo;Pegasystems ,&rdquo; &ldquo;our,&rdquo; &ldquo;us,&rdquo; or &ldquo;we&rdquo;), including, but not limited to,&nbsp;<a data-google-analytics-et-processed="true" href="https://www.pega.com/">https://www.pega.com</a>&nbsp;and&nbsp;<a data-google-analytics-et-processed="true" href="https://community.pega.com/">https://community.pega.com/</a>, that link to or incorporate these Terms of Use (the &ldquo;Online Services&rdquo;), and constitute a legal agreement between you and Pegasystems. Your access to and use of the Online Services and the information and materials available through the Online Services are subject to these Terms of Use, regardless of whether you possess an account through the Online Services linked to your or your employees&rsquo; or other end users&rsquo; names and/or contact information (&ldquo;Account&rdquo;). By accessing or using the Online Services, you acknowledge that you understand and agree to be bound by these Terms of Use and to comply with all applicable laws and regulations when using the Online Services. If you do not understand or agree to be bound by these Terms of Use, do not access, use, or create an Account for any of the Online Services.</p> <p><strong>1. CHANGES TO THESE TERMS OF USE</strong></p> <p>We reserve the right to modify these Terms of Use, in whole or in part, in our own discretion at any time. Such modifications shall be effective immediately upon the linking of modified Terms of Use to the Online Services, and if you possess an Account, by communicating the modifications to you by sending them to the contact information that you have provided to us. You agree to comply with, and be bound by, any such modifications either (a) by continuing to use or access the Online Services after modified Terms of Use are posted to the Online Services or (b) if you possess an Account, by not requesting to terminate your Account within seven (7) days after being sent a notice of modifications as described above.</p> <p><strong>2. ONLINE SERVICES</strong></p> <p><u>Ownership of Intellectual Property</u></p> <p>All text, graphics, user interfaces, visual interfaces, photographs, videos, trademarks, logos, sounds, music, artwork, and computer code (collectively, &ldquo;Content&rdquo;), including, but not limited to, the design, structure, selection, coordination, expression, and arrangement of other Content, which is contained on the Online Services is owned, controlled, or licensed by or to Pegasystems, and is protected by trade dress, copyright, patent, and trademark laws, and various other intellectual property rights and unfair competition laws. By granting you access to and use of the Online Services, Pegasystems does not transfer any ownership rights in any Content found on the Online Services, and by furnishing information and materials through the Online Services, Pegasystems does not grant any licenses to any copyrights, patents, or any other intellectual property rights.</p> <p>Except as expressly provided in these Terms of Use, no part of the Online Services and no Content may be copied, reproduced, republished, uploaded, posted, publicly displayed, encoded, translated, transmitted, or distributed in any way (including &ldquo;mirroring&rdquo;) to any other computer, server, website, or other medium for publication or distribution or for any commercial enterprise, without Pegasystems&rsquo; express prior written consent. Notwithstanding the foregoing, you may view, use, download, and print selected portions of the Online Services solely for your own personal, noncommercial, informational use; provided that you do not republish such Content and that you keep intact all copyright, trademark, service mark, attribution, patent, and other proprietary notices.</p> <p>The Online Services may contain other proprietary notices and copyright information, the terms of which must be observed and followed.</p>`
};

window.PCore.getDataPageUtils = () => {
  return {
    getPageDataAsync: () => {
      return new Promise(resolve => {
        resolve(viewData);
      });
    }
  };
};

export const BaseEeExtShowParagraph: Story = args => {
  const props = {
    ...configProps
  };

  return (
    <>
      <EeExtShowParagraph {...props} {...args} />
    </>
  );
};

BaseEeExtShowParagraph.args = {
  dataPage: configProps.dataPage,
  className: configProps.className,
  paragraphName: configProps.paragraphName
};
