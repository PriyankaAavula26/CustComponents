import { withConfiguration } from '@pega/cosmos-react-core';
import type { PConnFieldProps } from './PConnProps';

import { useState, useEffect } from 'react';

import StyledEeExtShowParagraphWrapper from './styles';

// interface for props
interface EeExtShowParagraphProps extends PConnFieldProps {
  // If any, enter additional props that only exist on TextInput here
  dataPage: string;
  className: string;
  paragraphName: string;
}

// Duplicated runtime code from Constellation Design System Component

// props passed in combination of props from property panel (config.json) and run time props from Constellation
// any default values in config.pros should be set in defaultProps at bottom of this file
function EeExtShowParagraph(props: EeExtShowParagraphProps) {
  const { dataPage, className, paragraphName } = props;
  const dataViewName = dataPage;

  const [htmlText, setHtmlText] = useState<string>('');

  useEffect(() => {
    if (dataViewName != '') {
      const options = {
        invalidateCache: true
      };
      const parameters = {
        pyClassName: className,
        pyStreamName: paragraphName
      };
      const context = 'app/primary_1';
      PCore.getDataPageUtils()
        .getPageDataAsync(dataViewName, context, parameters, options)
        .then((response: any) => {
          setHtmlText(response.pySourceStream);
        })
        .catch(() => {});
    }
  }, [dataViewName, className, paragraphName]);

  function myText() {
    const para = document.getElementById('showpara')!;
    if (para) {
      para.innerHTML = htmlText;
    }
    return null;
  }

  return (
    <StyledEeExtShowParagraphWrapper>
      <div id='showpara' className='paragraph'>
        {myText()}
      </div>
    </StyledEeExtShowParagraphWrapper>
  );
}

export default withConfiguration(EeExtShowParagraph);
