// @ts-nocheck
const configProps = {
  dataPage: 'D_GetParagraph',
  className: '@baseclass',
  paragraphName: 'UserAgreement'
};
export default configProps;
