import styled, { css } from 'styled-components';
import { Button, Icon, Tooltip, useElement, registerIcon } from '@pega/cosmos-react-core';

import * as phoneSolidIcon from '@pega/cosmos-react-core/lib/components/Icon/icons/phone-solid.icon';

registerIcon(phoneSolidIcon);

const WrapperDiv = styled.div(() => {
  return css`
    .main-container {
      color: rgb(255, 255, 255);
      background-color: rgba(255, 255, 255, 0);
      padding: calc(0.78125rem) 0;
      position: relative;
      display: flex;
      align-items: center;
      font-weight: 400;
      text-decoration: none;
      width: 100%;
    }

    .main-container:hover {
      background-color: rgb(5, 124, 105);
    }

    .sub-container {
      flex-shrink: 0;
      margin: 0px calc(1.4375rem);
    }
  `;
});

export default function EeExtUserHelp(props: any) {
  const { url, label } = props;

  const itemClick = () => {
    window.open(url, '_blank');
  };

  const [el, setEl] = useElement();

  return (
    <WrapperDiv>
      <Button
        variant='text'
        icon
        compact={false}
        onClick={itemClick}
        className='main-container'
        ref={setEl}
      >
        <span className='sub-container'>
          {el && (
            <Tooltip target={el} placement='right' showDelay='none' hideDelay='none'>
              {label}
            </Tooltip>
          )}

          <Icon name='phone-solid' />
        </span>
        <span>{label}</span>
      </Button>
    </WrapperDiv>
  );
}
