
/* eslint-disable react/jsx-no-useless-fragment */
// @ts-nocheck
import type { Meta, StoryObj } from '@storybook/react';

import EeExtUserHelp from './index';


import configProps from './mock';

const meta: Meta<typeof EeExtUserHelp> = {
  title: 'EeExtUserHelp',
  component: EeExtUserHelp,
  excludeStories: /.*Data$/
};

export default meta;
type Story = StoryObj<typeof EeExtUserHelp>;

export const BaseEeExtUserHelp: Story = args => {

  const props = {
    label: configProps.label,
    header: configProps.header,
    description: configProps.description,
    image: configProps.image,
    datasource: configProps.datasource,
    whatsnewlink: configProps.whatsnewlink
};

return (
    <>
      <EeExtUserHelp {...props} {...args} />
    </>
  );
};

BaseEeExtUserHelp.args = {
  header: configProps.header,
  description: configProps.description
};
