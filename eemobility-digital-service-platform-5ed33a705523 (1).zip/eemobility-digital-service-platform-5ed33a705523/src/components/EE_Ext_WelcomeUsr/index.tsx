import { withConfiguration, Text } from '@pega/cosmos-react-core';
import type { PConnFieldProps } from './PConnProps';

import StyledCard from './styles';

interface EeExtWelcomeUsrProps extends PConnFieldProps {
  label: string;
  labelColor: string;
  labelSize: string;
  labelWeight: string;
}

function EeExtWelcomeUsr(props: EeExtWelcomeUsrProps) {
  const { label, labelColor, labelSize, labelWeight } = props;

  // The styling passed from configuration is used here to style the label
  const labelStyle = { color: labelColor, 'font-size': labelSize, 'font-weight': labelWeight };

  // The below code fetches the Operator Name using PCore api and extracts the first name.
  const firstName = PCore.getEnvironmentInfo().getOperatorName().split(' ')[0];
  return (
    // The label provided from App Studio is displayed before first name.
    <Text as={StyledCard}>
      <span style={labelStyle}>
        {label} {firstName}
      </span>
    </Text>
  );
}

export default withConfiguration(EeExtWelcomeUsr);
