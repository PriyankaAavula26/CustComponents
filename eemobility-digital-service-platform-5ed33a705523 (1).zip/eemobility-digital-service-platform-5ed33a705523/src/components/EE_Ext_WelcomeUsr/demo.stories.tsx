
/* eslint-disable react/jsx-no-useless-fragment */
// @ts-nocheck
import type { Meta, StoryObj } from '@storybook/react';

import EeExtWelcomeUsr from './index';


import configProps from './mock';

const meta: Meta<typeof EeExtWelcomeUsr> = {
  title: 'EeExtWelcomeUsr',
  component: EeExtWelcomeUsr,
  excludeStories: /.*Data$/
};

export default meta;
type Story = StoryObj<typeof EeExtWelcomeUsr>;

export const BaseEeExtWelcomeUsr: Story = args => {

  const props = {
    label: configProps.label,
    header: configProps.header,
    description: configProps.description,
    image: configProps.image,
    datasource: configProps.datasource,
    whatsnewlink: configProps.whatsnewlink
};

return (
    <>
      <EeExtWelcomeUsr {...props} {...args} />
    </>
  );
};

BaseEeExtWelcomeUsr.args = {
  header: configProps.header,
  description: configProps.description
};
